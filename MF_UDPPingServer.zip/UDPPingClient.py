#Mark Feehily
#Comp 430
#3/13/2021
import socket
from socket import AF_INET, SOCK_DGRAM
import time

UDP_IP_ADDRESS = '127.0.0.1' 
UDP_PORT_NO = 3746

print('Ping',UDP_IP_ADDRESS,UDP_PORT_NO)
clientSocket = socket.socket(AF_INET,SOCK_DGRAM)
clientSocket.settimeout(3)
sequence_number = 1
rtt=[]
while sequence_number<=10:
    
    start=time.time()
    message = str(sequence_number)
    clientSocket.sendto(message.encode('utf-8'),(UDP_IP_ADDRESS, UDP_PORT_NO))
    try:
        message, address = clientSocket.recvfrom(1024) 
        elapsed = (time.time()-start) 
        rtt.append(elapsed)
        print('message number'+str(sequence_number)+'RTT:' + str(elapsed) +' secs')
    
    except socket.timeout:       
        print('message number'+str(sequence_number)+'timed out')

    sequence_number+=1
    print( '')
    if sequence_number > 10:
        print('packets sent:',sequence_number-1)
        print('packets received:',len(rtt))
        print('loss rate is:' + str((10-len(rtt))*10)+ '%')
        mean=sum(rtt, 0.0)/ len(rtt)       
        print( 'RTT is:' + str(max(rtt)) + 'seconds')
        print( 'RTT is:' + str(min(rtt)) + 'seconds')
        print( 'Average RTT is:' + str(mean)+ 'seconds')
        #clientSocket.close()