#Mark Feehily
#Comp 430
#3/13/2021
import random
from socket import *

serverSocket = socket(AF_INET, SOCK_DGRAM)

serverSocket.bind(('', 3746))

print('The server is ready to receive on port: 12000')

while True:
    rand=random.randint(0, 10)
   
    message,address = serverSocket.recvfrom(1024)
    message = message.upper()
    print('ping request'+ message.decode('utf-8'))
    if rand < 4:
        print('sequence number '+ message.decode('utf-8') +' dropped')
        continue

    serverSocket.sendto(message, address)