//
//  ViewController.swift
//  DiceGame
//
//  Created by Kevin Ho and Mark Feehily on 4/27/20.
//  Copyright © 2020 Kevin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    //Outlets variables
    @IBOutlet weak var firstDiceImage: UIImageView!
    
    @IBOutlet weak var secondDiceImage: UIImageView!
    
    @IBOutlet weak var scoreText: UILabel!
    
    @IBOutlet weak var rollDice: UIButton!
    
    @IBOutlet weak var helpAlert: UIButton!
    
    
    //Dice roll action, when tapped or clicked on the two images will show different dice numbers from 1-6 and display the sum of the two dice numbers as the score under the label text. If the sum of two numbers is 6 or higher, an alert will show.
    @IBAction func rollTapped(_ sender: Any) {
 
        let randomOne = arc4random_uniform(5) + 1
        let randomTwo = arc4random_uniform(5) + 1
        
        scoreText.text = "Your Score is \(randomOne + randomTwo)"
        firstDiceImage.image = UIImage(named: "dice\(randomOne)")
        secondDiceImage.image = UIImage(named: "dice\(randomTwo)")
        
        if randomOne + randomTwo >= 6 {
            createAlert(title: "Level Complete", message: "Congrats! advance to next Level")
        }
    }
    
    //An alert function to be called and passed as references to the outlet actions
    func createAlert (title: String, message: String) {
        
        let alert2 = UIAlertController(title: title, message: message, preferredStyle : UIAlertControllerStyle.alert)
        
        alert2.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: { (action) in
            alert2.dismiss(animated: true, completion: nil)
        }))
        
        self.present(alert2, animated: true, completion: nil)
        
    }
    
    
    //An alert action to display to user when tapped or clicked how to play the game.
    @IBAction func helpAlert(_ sender: Any) {
        
        let alert = UIAlertController(title: "How To Play", message: "Click on dice to roll two dices and beat the number to move on", preferredStyle: UIAlertControllerStyle.alert)
        
        let defaultAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil)
        
        alert.addAction(defaultAction)
        
        present(alert, animated: true, completion: nil)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    //An alert called from func createAlert to display the objective.
    override func viewDidAppear(_ animated: Bool) {
        createAlert(title: "Objective", message: "Roll a 6 or higher to advance!")
    
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

