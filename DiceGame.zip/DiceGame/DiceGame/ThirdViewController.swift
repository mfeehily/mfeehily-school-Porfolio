//
//  ThirdViewController.swift
//  DiceGame
//
//  Created by Kevin Ho and Mark Feehily on 4/27/20.
//  Copyright © 2020 Kevin. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    //Outlets variables
    @IBOutlet weak var firstDiceImage: UIImageView!
    
    @IBOutlet weak var secondDiceImage: UIImageView!
    
    @IBOutlet weak var scoreText: UILabel!
    
    @IBOutlet weak var rollDice: UIButton!

    
    //Dice roll action, when tapped or clicked on the two images will show different dice numbers from 1-6 and display the sum of the two dice numbers as the score under the label text. If the sum of two numbers is 12, an alert will show.
    
    @IBAction func rollTapped(_ sender: Any) {
        
        let randomOne = arc4random_uniform(5) + 1
        let randomTwo = arc4random_uniform(5) + 1
        
        scoreText.text = "Your Score is \(randomOne + randomTwo)"
        firstDiceImage.image = UIImage(named: "dice\(randomOne)")
        secondDiceImage.image = UIImage(named: "dice\(randomTwo)")
        
        if randomOne + randomTwo == 12 {
            createAlert(title: "You Win!", message: "Do you want to play again?")
        }
    }
    
    //An alert function to be called and passed as references to the outlet actions
    func createAlert (title: String, message: String) {
        
        let alert2 = UIAlertController(title: title, message: message, preferredStyle : UIAlertControllerStyle.alert)
        
        alert2.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: { (action) in
            alert2.dismiss(animated: true, completion: nil)
        }))
        
        self.present(alert2, animated: true, completion: nil)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func viewDidAppear(_ animated: Bool) {
        createAlert(title: "Objective!", message: "Roll exactly a 12 to win!")
        
    }
    
    //An alert called from func createAlert to display the objective.
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
