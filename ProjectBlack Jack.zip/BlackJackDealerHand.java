package com.company;
/*
 *
 * BlackJackDealerHand.java
 *
 * completed by: Mark Feehily, MFeehily@student.bridgew.edu
 *
 * date: 11/27/18
 */

public class BlackJackDealerHand extends Hand{

    private boolean isDealerTurn;

    public BlackJackDealerHand(){
        super(20);
        isDealerTurn = false;
    }

    public void setDealerTurn(boolean test){

        if(test == true){
            isDealerTurn = true;
        }

    }

    @Override
    public String toString(){
        String str = "";
        for (int i = 0; i < getNumCards(); i++) {
            str += getCard(i); // Concatenate the card in position i to str,
            // implicitly calling the toString method in the Card class.

            if (i < getNumCards() - 1) { // If we're not at the last Card in the Hand,
                str += "  ";

                // then concatenate a space to prepare for printing the next Card.

            }

        }


        str += "  (value = " + getValue() + ")";

        return str;

    }

}
