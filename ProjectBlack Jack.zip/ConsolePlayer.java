package com.company;
/*
*
* ConsolePlayer.java
*
* completed by: Mark Feehily, MFeehily@student.bridgew.edu
*
* date: 11/27/18
*/
import java.util.Scanner;

public class ConsolePlayer extends Player {
    private Scanner console;

    public ConsolePlayer(Scanner console){
        this.console = console;

    }

    public boolean wantsHit(Hand ownHand, Hand opponentHand) {
        System.out.println("Want another hit (y/n) ?");
        String test = console.nextLine();

        if(test.equals("y")){
           return true;
        }
       return false;
    }


}
