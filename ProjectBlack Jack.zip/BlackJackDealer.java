package com.company;
/*
 *
 * BlackJackDealer.java
 *
 * completed by: Mark Feehily, MFeehily@student.bridgew.edu
 *
 * date: 11/27/18
 *
 */

public class BlackJackDealer extends Player{


    public boolean wantsHit(Hand ownHand, Hand opponentHand){
        if(ownHand.getValue() < 17){
            return true;
        }
        return false;
    }



}
