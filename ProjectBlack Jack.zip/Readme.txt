Readme:

Project BlackJack:

Blackjack.java

I used preliminary working code provided by:

Computer Science 111, Boston University
modified by: Laura K. Gross, laura.gross@bridgew.edu, November 14, 2018

Worked on by:

Mark Feehily, MFeehily@student.bridgew.edu

date: 11/27/18 