/*
 * BlackjackHand.java
 *
 * completed by: Mark Feehily, MFeehily@student.bridgew.edu
 *
 * date: 11/27/18
 */
package com.company;

public class BlackJackHand extends Hand {


    public BlackJackHand() {
        super(20);

    }

    @Override
    public int getValue() {
        int value = 0;
        for (int i = 0; i < getNumCards(); i++) {
            value += getCard(i).getDefaultValue();
            if (getCard(i).isAce() && value < 10) {
                value += 10;
            }
        }
        return value;
    }

    public void setBlackjack() {
        System.out.println("BlackJack");

    }
}
